package base;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class GenericWrapper {

	public static RemoteWebDriver driver;
	WebDriverWait wait; 
	
	public void launchBrowser(String browser, String url) {
		
		if(browser.equalsIgnoreCase("Chrome")) {
			WebDriverManager.chromedriver().setup();
			ChromeOptions ops =  new  ChromeOptions();
			ops.addArguments("--disable-notifications");
			driver = new ChromeDriver(ops);
		} if (browser.equalsIgnoreCase("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		}
	
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(45, TimeUnit.SECONDS); 
		wait = new WebDriverWait(driver,Duration.ofSeconds(30));
	}
	
	public WebElement locateElement(String locatorType, String locatorValue){
		switch (locatorType.toUpperCase()) {
		case "ID" : return driver.findElementById(locatorValue);
		case "CLASS" : return driver.findElementByClassName(locatorValue);
		case "XPATH" : return driver.findElementByXPath(locatorValue);
		case "NAME" : return driver.findElementByXPath(locatorValue);
		case "TEXT" : return driver.findElementByXPath(locatorValue);
		case "LINK": return driver.findElementByLinkText(locatorValue);					
		case "TAGNAME": return driver.findElementByTagName(locatorValue);
		case "PARTIALLINK": return driver.findElementByPartialLinkText(locatorValue);
		}
		return null;
	}
	
	public void enterValue(WebElement ele,String text){
		wait.until(ExpectedConditions.visibilityOf(ele));
		ele.sendKeys(text);
		}

	public void clickElement(WebElement element){
		wait.until(ExpectedConditions.elementToBeClickable(element));
		element.click();
	}
	
	public  void switchToIFrame(WebElement eleiFrame)
	{
		driver.switchTo().frame(eleiFrame);
	}
	
	public  void switchOutCurrentIFrame()
	{
		driver.switchTo().defaultContent();
	}
	
}
