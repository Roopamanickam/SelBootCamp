package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{

	public LoginPage(RemoteWebDriver driver) {
		this.driver = driver;
	}
	
	public LoginPage enterUsername(String username) {
		
		enterValue(locateElement("ID", "username"), username);
		
		return this;
	}
	
	public LoginPage enterPassword(String password) {
		enterValue(locateElement("id", "password"),password);
		//driver.findElementById("password").sendKeys(password);
		return this;
	}
	
	public LandingPage clickLoginButton(){
		//WebElement clk = driver.findElementById("Login");
		clickElement(locateElement("id","Login"));
			
		return new LandingPage(driver);
	} 
}
