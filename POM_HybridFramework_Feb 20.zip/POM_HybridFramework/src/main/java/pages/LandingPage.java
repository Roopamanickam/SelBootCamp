package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ProjectSpecificMethods;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LandingPage extends ProjectSpecificMethods{
	
	public LandingPage(RemoteWebDriver driver) {
		this.driver = driver;	
		}
	
	public LandingPage viewProfile()  {
		clickElement(locateElement("class","uiImage"));
		/*WebElement clkViewProfile = driver.findElementByXPath("//span[@class='uiImage']");
		clickElement(clkViewProfile);*/
		return this;
		}
	
	public LandingPage logout() {
		System.out.println("inside Logout ");
		WebElement clkLogOut = driver.findElementByXPath("//a[text()='Log Out']");
		clickElement(clkLogOut);
		return this;
	  }
	
	public LandingPage appLauncher(){ 
		clickElement(locateElement("class","slds-icon-waffle"));
		/*WebElement menu = driver.findElementByXPath("//div[@class='slds-icon-waffle']");
		clickElement(menu);*/
		return this;
	}
	
	public LandingPage searchAppItems(String searchAppItem) {
		//clickElement(locateElement("class","slds-input"));
		//driver.findElementByXPath("//input[@class='slds-input']").sendKeys(searchAppItem);
		enterValueKeysPress(locateElement("xpath", "//input[@class='slds-input']"), searchAppItem);
		//keysEnter(locateElement("class", "slds-input"));
		//driver.findElementByXPath("//input[@class='slds-input']").sendKeys(Keys.ENTER);
		
		return this;
	}
	
/*	public LandingPage viewAll(){
		clickElement(locateElement("xpath","//button[text()='View All']"));
		WebElement viewAll = driver.findElementByXPath("//button[text()='View All']");
		clickElement(viewAll);
		return this;
		
	}*/
	
	public LandingPage serviceTerritories(){
		clickElement(locateElement("class","slds-truncate"));
		return this;
	}
	
	public LandingPage clkcNew() {
		clickElement(locateElement("title","New"));
		return this;
	}
		
}
