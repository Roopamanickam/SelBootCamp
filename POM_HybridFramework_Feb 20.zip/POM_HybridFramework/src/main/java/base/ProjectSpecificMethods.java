package base;

import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ReadExcel;

public class ProjectSpecificMethods extends GenericWrapper{
	
	
	public String excelFileName;
	public static String oppId ;
	public boolean oppFound;
	

	@BeforeMethod
	public void startApp(){
		
		launchBrowser("Chrome","https://login.salesforce.com");
		
			
	}

		
	
	@AfterMethod
	public void closeBrowser() {
		//driver.close();
	}

	@DataProvider(name="fetchData")
	public String[][] sendData() throws IOException {

		//String[][] readData = ReadExcel.readData();
		ReadExcel re = new ReadExcel();
		String[][] readData = re.readData(excelFileName);
		return readData;
	}
}
