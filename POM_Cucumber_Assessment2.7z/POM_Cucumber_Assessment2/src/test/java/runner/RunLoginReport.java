package runner;


	import cucumber.api.CucumberOptions;
	import cucumber.api.SnippetType;
	import cucumber.api.testng.AbstractTestNGCucumberTests;
import pages.ParentClass;

	@CucumberOptions(features="src/main/resources/features/TC01_LoginAndLandingPage.feature", 
					glue="pages", 
					monochrome= true,
					tags ="@functional"
					)
	public class RunLoginReport extends AbstractTestNGCucumberTests {

	}
	

